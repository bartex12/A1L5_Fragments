package com.geekbrains.city_whether;

/**
* класс для констант*/

public class P {
    public static final String CITY = "CITY";
    public static final String WIND = "WIND";
    public static final String PRESSURE = "PRESSURE";
    public static final String CURRENT_POS = "CURRENT_POS";
    public static final String CITY_MARKED = "CITY_MARKED";

    public static final String CURRENT_CITY = "CURRENT_CITY";
    public static final String CURRENT_CITY_MARKED = "CURRENT_CITY_MARKED";

    public static final String SOME_KEY = "SOME_KEY";
    public static final String CURRENT_POSITION_DETAIL = "CURRENT_POSITION_DETAIL";
}
